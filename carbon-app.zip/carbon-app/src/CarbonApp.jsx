import React, { useState, useEffect, useCallback } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";
import { Zap, Droplets, Car, Trash2, Utensils, Leaf, ArrowLeft, ArrowRight, Lightbulb, Bus, Droplet, Apple, Award, TrendingDown, ChevronRight, RotateCcw, User, Mail, Lock } from "lucide-react";
import { storage } from "./storage";

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap');
`;

const PALETTE = {
  forest: "#1B2E22",
  forestDeep: "#1B5E20",
  paper: "#F3EEE2",
  paperDim: "#E9E2D2",
  clay: "#2E7D32",
  clayDeep: "#1B5E20",
  sage: "#43A047",
  sageLight: "#A5D6A7",
  amber: "#FB8C00",
  ink: "#1B2419",
};

const CATEGORY_COLORS = {
  Energy: "#4CAF50",
  Water: "#2196F3",
  Transport: "#1976D2",
  Food: "#FF9800",
  Waste: "#388E3C",
};

const EMISSION_FACTORS = {
  electricity: 0.82, // kg CO2 per kWh
  lpg: 2.98, // kg CO2 per kg LPG
  induction: 0.41, // kg CO2 per hour/day (approx via kWh)
  fridge: 0.5, // kg CO2 per day baseline
  ac: 0.65, // kg CO2 per hour/day
  water: 0.0003, // kg CO2 per litre
  car: 0.21, // kg CO2 per km
  bike: 0,
  bus: 0.05,
  train: 0.04,
  dietVeg: 60, // kg CO2 per month baseline
  dietNonVeg: 150,
  dietMixed: 100,
  dryWaste: 0.6, // kg CO2 per kg/week -> monthly approx
  wetWaste: 0.3,
};

const defaultEntries = {
  electricity: "", lpg: "", induction: "", fridgeHrs: "", acHrs: "",
  water: "",
  car: "", bike: "", bus: "", train: "",
  diet: "mixed",
  dryWaste: "", wetWaste: "",
};

function num(v) { const n = parseFloat(v); return isNaN(n) ? 0 : n; }

function computeFootprint(e) {
  const energy = num(e.electricity) * EMISSION_FACTORS.electricity * 30
    + num(e.lpg) * EMISSION_FACTORS.lpg
    + num(e.induction) * EMISSION_FACTORS.induction * 30
    + (e.fridgeHrs ? EMISSION_FACTORS.fridge * 30 : 0)
    + num(e.acHrs) * EMISSION_FACTORS.ac * 30;
  const water = num(e.water) * EMISSION_FACTORS.water * 30;
  const transport = (num(e.car) * EMISSION_FACTORS.car
    + num(e.bike) * EMISSION_FACTORS.bike
    + num(e.bus) * EMISSION_FACTORS.bus
    + num(e.train) * EMISSION_FACTORS.train) * 4.3;
  const dietKey = e.diet === "veg" ? "dietVeg" : e.diet === "nonveg" ? "dietNonVeg" : "dietMixed";
  const food = EMISSION_FACTORS[dietKey];
  const waste = (num(e.dryWaste) * EMISSION_FACTORS.dryWaste + num(e.wetWaste) * EMISSION_FACTORS.wetWaste) * 4.3;

  return {
    Energy: Math.round(energy),
    Water: Math.round(water),
    Transport: Math.round(transport),
    Food: Math.round(food),
    Waste: Math.round(waste),
    total: Math.round(energy + water + transport + food + waste),
  };
}

function ratingFor(total) {
  if (total < 400) return { label: "Low", color: PALETTE.sage };
  if (total < 800) return { label: "Medium", color: PALETTE.amber };
  return { label: "High", color: PALETTE.clay };
}

function Gauge({ total }) {
  const max = 1200;
  const pct = Math.min(total / max, 1);
  const angle = -90 + pct * 180;
  const rating = ratingFor(total);
  return (
    <div style={{ position: "relative", width: 200, height: 110, margin: "0 auto" }}>
      <svg width="200" height="110" viewBox="0 0 200 110">
        <defs>
          <linearGradient id="gaugeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={PALETTE.sage} />
            <stop offset="55%" stopColor={PALETTE.amber} />
            <stop offset="100%" stopColor={PALETTE.clay} />
          </linearGradient>
        </defs>
        <path d="M 10 100 A 90 90 0 0 1 190 100" fill="none" stroke="#E0D7C2" strokeWidth="14" strokeLinecap="round" />
        <path d="M 10 100 A 90 90 0 0 1 190 100" fill="none" stroke="url(#gaugeGrad)" strokeWidth="14" strokeLinecap="round"
          strokeDasharray={`${pct * 283} 283`} />
        <g transform={`rotate(${angle} 100 100)`}>
          <line x1="100" y1="100" x2="100" y2="30" stroke={PALETTE.ink} strokeWidth="3" strokeLinecap="round" />
        </g>
        <circle cx="100" cy="100" r="7" fill={PALETTE.ink} />
      </svg>
      <div style={{ textAlign: "center", marginTop: -6 }}>
        <span style={{ fontFamily: "'Roboto', sans-serif", fontWeight: 600, fontSize: 13, letterSpacing: 1, color: rating.color, textTransform: "uppercase" }}>
          {rating.label}
        </span>
      </div>
    </div>
  );
}

function Card({ children, style }) {
  return (
    <div style={{
      background: PALETTE.paper,
      border: `1px solid ${PALETTE.paperDim}`,
      borderRadius: 14,
      padding: 20,
      boxShadow: "0 1px 0 rgba(0,0,0,0.04)",
      ...style,
    }}>
      {children}
    </div>
  );
}

function NumberField({ icon: Icon, label, unit, value, onChange }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: PALETTE.forest, fontWeight: 600, marginBottom: 6 }}>
        {Icon && <Icon size={15} color={PALETTE.clay} />} {label}
      </label>
      <div style={{ display: "flex", alignItems: "center", border: `1.5px solid ${PALETTE.paperDim}`, borderRadius: 10, background: "#fff", overflow: "hidden" }}>
        <input
          type="number"
          min="0"
          inputMode="decimal"
          value={value}
          onChange={(ev) => onChange(ev.target.value)}
          placeholder="0"
          style={{
            flex: 1, border: "none", outline: "none", padding: "10px 12px",
            fontFamily: "'Roboto', sans-serif", fontSize: 15, color: PALETTE.ink, background: "transparent",
          }}
        />
        {unit && <span style={{ padding: "0 12px", fontSize: 12, color: "#8A8073", whiteSpace: "nowrap" }}>{unit}</span>}
      </div>
    </div>
  );
}

const NAV = [
  { key: "dashboard", label: "Dashboard", icon: Leaf },
  { key: "results", label: "Insights", icon: Zap },
  { key: "suggestions", label: "Tips", icon: Lightbulb },
  { key: "progress", label: "Progress", icon: TrendingDown },
];

export default function CarbonApp() {
  const [screen, setScreen] = useState("dashboard");
  const [entries, setEntries] = useState(defaultEntries);
  const [history, setHistory] = useState([]);
  const [badges, setBadges] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [user, setUser] = useState(null);
  const [pendingOtp, setPendingOtp] = useState(null);
  const [pendingUser, setPendingUser] = useState(null);
  const [authError, setAuthError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const u = await storage.get("carbon:user");
        if (u && u.value) setUser(JSON.parse(u.value));
      } catch (e) {}
      try {
        const r = await storage.get("carbon:state");
        if (r && r.value) {
          const parsed = JSON.parse(r.value);
          setEntries(parsed.entries || defaultEntries);
          setHistory(parsed.history || []);
          setBadges(parsed.badges || 0);
        }
      } catch (e) { /* no saved state yet */ }
      setLoaded(true);
    })();
  }, []);

  const persist = useCallback(async (next) => {
    try { await storage.set("carbon:state", JSON.stringify(next)); } catch (e) {}
  }, []);

  const setField = (k, v) => setEntries((prev) => ({ ...prev, [k]: v }));

  const result = computeFootprint(entries);
  const rating = ratingFor(result.total);
  const prev = history.length ? history[history.length - 1] : null;
  const reduction = prev ? Math.round(((prev.total - result.total) / prev.total) * 100) : null;

  const pieData = ["Energy", "Water", "Transport", "Food", "Waste"]
    .map((k) => ({ name: k, value: result[k] }))
    .filter((d) => d.value > 0);

  const saveSnapshot = () => {
    const entry = { total: result.total, breakdown: result, date: new Date().toISOString() };
    const nextHistory = [...history, entry].slice(-12);
    let nextBadges = badges;
    if (prev && result.total < prev.total) nextBadges += 1;
    setHistory(nextHistory);
    setBadges(nextBadges);
    persist({ entries, history: nextHistory, badges: nextBadges });
    setScreen("results");
  };

  const resetAll = async () => {
    setEntries(defaultEntries);
    setHistory([]);
    setBadges(0);
    await persist({ entries: defaultEntries, history: [], badges: 0 });
    setScreen("dashboard");
  };

  const handleSendOtp = async ({ name, email }) => {
    setAuthError("");
    if (!email) { setAuthError("Please enter your email or phone number."); return; }
    const code = String(Math.floor(1000 + Math.random() * 9000));
    setPendingOtp(code);
    setPendingUser({ name: name || "there", email });
    try {
      await storage.set("carbon:user", JSON.stringify({ name: name || "there", email }));
    } catch (e) {}
  };

  const handleVerifyOtp = (code) => {
    setAuthError("");
    if (code === pendingOtp) {
      setUser(pendingUser);
      setPendingOtp(null);
    } else {
      setAuthError("That code didn't match. Please try again.");
    }
  };

  const handleLogout = async () => {
    setUser(null);
    setPendingOtp(null);
    setPendingUser(null);
    setAuthError("");
  };

  if (!loaded) return null;

  if (!user) {
    return (
      <AuthScreen
        pendingOtp={pendingOtp}
        pendingUser={pendingUser}
        error={authError}
        onSendOtp={handleSendOtp}
        onVerifyOtp={handleVerifyOtp}
        onBack={() => { setPendingOtp(null); setAuthError(""); }}
      />
    );
  }

  return (
    <div style={{
      minHeight: "100vh",
      background: PALETTE.forestDeep,
      display: "flex",
      justifyContent: "center",
      padding: "24px 12px",
      fontFamily: "'Poppins', sans-serif",
    }}>
      <style>{FONTS}{`
        * { box-sizing: border-box; }
        input::-webkit-outer-spin-button, input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
        button { font-family: 'Poppins', sans-serif; cursor: pointer; }
        ::selection { background: ${PALETTE.clay}; color: #fff; }
      `}</style>

      <div style={{
        width: 420, maxWidth: "100%",
        background: PALETTE.forest,
        borderRadius: 26,
        overflow: "hidden",
        boxShadow: "0 30px 60px rgba(0,0,0,0.45)",
        border: `1px solid #2A3C30`,
      }}>
        {/* Header */}
        <div style={{ padding: "22px 22px 18px", background: PALETTE.forest }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{
                width: 36, height: 36, borderRadius: 10, background: PALETTE.clay,
                display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
              }}>
                <Leaf size={19} color="#fff" />
              </div>
              <div>
                <div style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 600, fontSize: 17, color: PALETTE.paper, lineHeight: 1.15 }}>
                  Carbon Calculator
                </div>
                <div style={{ fontSize: 11.5, color: PALETTE.sageLight, letterSpacing: 0.3 }}>
                  Welcome, {user.name}
                </div>
              </div>
            </div>
            <button onClick={handleLogout} style={{
              background: "none", border: `1px solid ${PALETTE.sageLight}`, borderRadius: 8,
              padding: "5px 10px", color: PALETTE.sageLight, fontSize: 11, fontWeight: 600,
            }}>
              Log out
            </button>
          </div>
        </div>

        {/* Body */}
        <div style={{ background: PALETTE.paper, minHeight: 560, padding: "22px 18px 90px", position: "relative" }}>
          {screen === "dashboard" && (
            <DashboardScreen entries={entries} setField={setField} result={result} rating={rating}
              onCalculate={saveSnapshot} />
          )}
          {screen === "results" && (
            <ResultsScreen result={result} rating={rating} pieData={pieData} onNext={() => setScreen("suggestions")} />
          )}
          {screen === "suggestions" && (
            <SuggestionsScreen result={result} badges={badges} onProgress={() => setScreen("progress")} />
          )}
          {screen === "progress" && (
            <ProgressScreen history={history} badges={badges} reduction={reduction} onReset={resetAll} />
          )}
        </div>

        {/* Bottom nav */}
        <div style={{
          position: "sticky", bottom: 0, background: PALETTE.paper,
          borderTop: `1px solid ${PALETTE.paperDim}`,
          display: "flex", justifyContent: "space-around", padding: "10px 6px 14px",
        }}>
          {NAV.map(({ key, label, icon: Icon }) => {
            const active = screen === key;
            return (
              <button key={key} onClick={() => setScreen(key)} style={{
                background: "none", border: "none", display: "flex", flexDirection: "column",
                alignItems: "center", gap: 4, padding: "4px 10px",
              }}>
                <Icon size={19} color={active ? PALETTE.clay : "#9A9181"} />
                <span style={{ fontSize: 10.5, fontWeight: 600, color: active ? PALETTE.clay : "#9A9181" }}>{label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function SectionLabel({ children }) {
  return (
    <div style={{
      fontFamily: "'Poppins', sans-serif", fontSize: 22, fontWeight: 600, color: PALETTE.forest,
      marginBottom: 4,
    }}>{children}</div>
  );
}

function DashboardScreen({ entries, setField, result, rating, onCalculate }) {
  const [tab, setTab] = useState("energy");

  const tabs = [
    { key: "energy", label: "Energy", icon: Zap },
    { key: "water", label: "Water", icon: Droplets },
    { key: "transport", label: "Transport", icon: Car },
    { key: "food", label: "Food", icon: Utensils },
    { key: "waste", label: "Waste", icon: Trash2 },
  ];

  return (
    <div>
      <SectionLabel>Your inputs</SectionLabel>
      <div style={{ fontSize: 13, color: "#6B6253", marginBottom: 16 }}>
        Fill in a category, then calculate your footprint.
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 16, flexWrap: "wrap" }}>
        {tabs.map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => setTab(key)} style={{
            display: "flex", alignItems: "center", gap: 5,
            padding: "7px 11px", borderRadius: 20, border: `1.5px solid ${tab === key ? PALETTE.clay : PALETTE.paperDim}`,
            background: tab === key ? PALETTE.clay : "#fff", color: tab === key ? "#fff" : PALETTE.forest,
            fontSize: 12.5, fontWeight: 600,
          }}>
            <Icon size={13} /> {label}
          </button>
        ))}
      </div>

      <Card>
        {tab === "energy" && (
          <>
            <NumberField icon={Zap} label="Electricity usage" unit="kWh / day" value={entries.electricity} onChange={(v) => setField("electricity", v)} />
            <NumberField icon={Zap} label="LPG usage" unit="kg / month" value={entries.lpg} onChange={(v) => setField("lpg", v)} />
            <NumberField icon={Zap} label="Induction stove" unit="hrs / day" value={entries.induction} onChange={(v) => setField("induction", v)} />
            <NumberField icon={Zap} label="Refrigerator" unit="hrs / day" value={entries.fridgeHrs} onChange={(v) => setField("fridgeHrs", v)} />
            <NumberField icon={Zap} label="Air conditioner" unit="hrs / day" value={entries.acHrs} onChange={(v) => setField("acHrs", v)} />
          </>
        )}
        {tab === "water" && (
          <NumberField icon={Droplets} label="Water consumption" unit="litres / day" value={entries.water} onChange={(v) => setField("water", v)} />
        )}
        {tab === "transport" && (
          <>
            <NumberField icon={Car} label="Car travel" unit="km / week" value={entries.car} onChange={(v) => setField("car", v)} />
            <NumberField icon={Bus} label="Bus travel" unit="km / week" value={entries.bus} onChange={(v) => setField("bus", v)} />
            <NumberField icon={Car} label="Train travel" unit="km / week" value={entries.train} onChange={(v) => setField("train", v)} />
            <NumberField icon={Car} label="Bike travel" unit="km / week" value={entries.bike} onChange={(v) => setField("bike", v)} />
          </>
        )}
        {tab === "food" && (
          <div>
            <label style={{ display: "block", fontSize: 13, color: PALETTE.forest, fontWeight: 600, marginBottom: 8 }}>
              Diet type
            </label>
            <div style={{ display: "flex", gap: 8 }}>
              {[{ k: "veg", l: "Vegetarian" }, { k: "nonveg", l: "Non-Veg" }, { k: "mixed", l: "Mixed" }].map((d) => (
                <button key={d.k} onClick={() => setField("diet", d.k)} style={{
                  flex: 1, padding: "10px 6px", borderRadius: 10,
                  border: `1.5px solid ${entries.diet === d.k ? PALETTE.sage : PALETTE.paperDim}`,
                  background: entries.diet === d.k ? PALETTE.sage : "#fff",
                  color: entries.diet === d.k ? "#fff" : PALETTE.forest, fontSize: 12.5, fontWeight: 600,
                }}>{d.l}</button>
              ))}
            </div>
          </div>
        )}
        {tab === "waste" && (
          <>
            <NumberField icon={Trash2} label="Dry waste" unit="kg / week" value={entries.dryWaste} onChange={(v) => setField("dryWaste", v)} />
            <NumberField icon={Trash2} label="Wet waste" unit="kg / week" value={entries.wetWaste} onChange={(v) => setField("wetWaste", v)} />
          </>
        )}
      </Card>

      <Card style={{ marginTop: 16 }}>
        <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: 0.5, color: "#8A8073", textTransform: "uppercase", marginBottom: 4 }}>
          Instant result
        </div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
          <span style={{ fontFamily: "'Roboto', sans-serif", fontSize: 34, fontWeight: 600, color: PALETTE.forest }}>
            {result.total}
          </span>
          <span style={{ fontSize: 13, color: "#6B6253" }}>kg CO₂e / month</span>
        </div>
        <div style={{ marginTop: 6, fontSize: 12.5, fontWeight: 700, color: rating.color }}>{rating.label} footprint</div>
      </Card>

      <button onClick={onCalculate} style={{
        width: "100%", marginTop: 16, padding: "14px", borderRadius: 12, border: "none",
        background: PALETTE.clay, color: "#fff", fontSize: 14.5, fontWeight: 700,
        display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
      }}>
        Calculate footprint <ArrowRight size={16} />
      </button>
    </div>
  );
}

function ResultsScreen({ result, rating, pieData, onNext }) {
  return (
    <div>
      <SectionLabel>Your carbon footprint</SectionLabel>
      <div style={{ fontSize: 13, color: "#6B6253", marginBottom: 16 }}>Based on your latest inputs.</div>

      <Card>
        <div style={{ textAlign: "center" }}>
          <span style={{ fontFamily: "'Roboto', sans-serif", fontSize: 40, fontWeight: 700, color: PALETTE.forest }}>
            {result.total}
          </span>
          <div style={{ fontSize: 13, color: "#6B6253" }}>kg CO₂e / month</div>
        </div>

        {pieData.length > 0 ? (
          <div style={{ width: "100%", height: 200, marginTop: 8 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={48} outerRadius={78} paddingAngle={2}>
                  {pieData.map((d) => <Cell key={d.name} fill={CATEGORY_COLORS[d.name]} stroke={PALETTE.paper} strokeWidth={2} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div style={{ textAlign: "center", color: "#8A8073", fontSize: 13, padding: "30px 0" }}>
            Add some inputs on the Dashboard to see your breakdown.
          </div>
        )}

        <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 14px", justifyContent: "center", marginBottom: 14 }}>
          {Object.keys(CATEGORY_COLORS).map((k) => (
            <div key={k} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11.5, color: PALETTE.forest }}>
              <span style={{ width: 9, height: 9, borderRadius: 3, background: CATEGORY_COLORS[k], display: "inline-block" }} />
              {k}
            </div>
          ))}
        </div>

        <Gauge total={result.total} />
      </Card>

      <Card style={{ marginTop: 16 }}>
        <div style={{ fontFamily: "'Poppins', sans-serif", fontSize: 16, fontWeight: 600, color: PALETTE.forest, marginBottom: 10 }}>
          Category breakdown
        </div>
        {["Energy", "Water", "Transport", "Food", "Waste"].map((k) => {
          const max = Math.max(result.total, 1);
          const w = Math.round((result[k] / max) * 100);
          return (
            <div key={k} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 4 }}>
                <span style={{ color: PALETTE.forest, fontWeight: 600 }}>{k}</span>
                <span style={{ fontFamily: "'Roboto', sans-serif", color: "#6B6253" }}>{result[k]} kg</span>
              </div>
              <div style={{ height: 7, background: PALETTE.paperDim, borderRadius: 4, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${w}%`, background: CATEGORY_COLORS[k], borderRadius: 4 }} />
              </div>
            </div>
          );
        })}
      </Card>

      <button onClick={onNext} style={{
        width: "100%", marginTop: 16, padding: "14px", borderRadius: 12, border: "none",
        background: PALETTE.forest, color: PALETTE.paper, fontSize: 14.5, fontWeight: 700,
        display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
      }}>
        See suggestions <ArrowRight size={16} />
      </button>
    </div>
  );
}

function tipsFor(result) {
  const tips = [];
  if (result.Energy > 250) tips.push({ icon: Lightbulb, t: "Switch to LED bulbs and unplug idle appliances to cut electricity use." });
  if (result.Transport > 150) tips.push({ icon: Bus, t: "Swap a few car trips a week for bus, train, or biking." });
  if (result.Food > 100) tips.push({ icon: Apple, t: "Adding a few plant-based meals a week meaningfully lowers food emissions." });
  if (result.Waste > 60) tips.push({ icon: Trash2, t: "Segregate dry and wet waste, and compost food scraps where possible." });
  if (result.Water > 30) tips.push({ icon: Droplet, t: "Shorter showers and fixing leaks can meaningfully cut water-related emissions." });
  if (tips.length === 0) {
    tips.push({ icon: Leaf, t: "Your footprint looks light already — keep up these habits." });
  }
  return tips;
}

function SuggestionsScreen({ result, badges, onProgress }) {
  const tips = tipsFor(result);
  return (
    <div>
      <SectionLabel>Tips to reduce your footprint</SectionLabel>
      <div style={{ fontSize: 13, color: "#6B6253", marginBottom: 16 }}>Tailored to where your emissions are highest.</div>

      {tips.map((tip, i) => (
        <Card key={i} style={{ marginBottom: 10, display: "flex", alignItems: "flex-start", gap: 12, padding: 16 }}>
          <div style={{
            width: 34, height: 34, borderRadius: 9, background: PALETTE.paperDim,
            display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
          }}>
            <tip.icon size={17} color={PALETTE.clay} />
          </div>
          <div style={{ fontSize: 13.5, color: PALETTE.ink, lineHeight: 1.4, paddingTop: 4 }}>{tip.t}</div>
        </Card>
      ))}

      <Card style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{
          width: 42, height: 42, borderRadius: "50%", background: PALETTE.sage,
          display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
        }}>
          <Award size={20} color="#fff" />
        </div>
        <div style={{ fontSize: 13.5, color: PALETTE.forest, fontWeight: 600 }}>
          {badges} Green {badges === 1 ? "Badge" : "Badges"} earned
        </div>
      </Card>

      <button onClick={onProgress} style={{
        width: "100%", marginTop: 16, padding: "14px", borderRadius: 12, border: "none",
        background: PALETTE.clay, color: "#fff", fontSize: 14.5, fontWeight: 700,
        display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
      }}>
        View progress <ArrowRight size={16} />
      </button>
    </div>
  );
}

function ProgressScreen({ history, badges, reduction, onReset }) {
  const last = history.slice(-6);
  const max = Math.max(...last.map((h) => h.total), 1);
  const reversedAll = [...history].reverse();
  const [openIdx, setOpenIdx] = useState(null);

  return (
    <div>
      <SectionLabel>Progress tracker</SectionLabel>
      <div style={{ fontSize: 13, color: "#6B6253", marginBottom: 16 }}>Each calculation is saved as a snapshot.</div>

      <Card>
        <div style={{ fontFamily: "'Poppins', sans-serif", fontSize: 16, fontWeight: 600, color: PALETTE.forest, marginBottom: 14 }}>
          Monthly comparison
        </div>
        {last.length === 0 ? (
          <div style={{ textAlign: "center", color: "#8A8073", fontSize: 13, padding: "20px 0" }}>
            Calculate your footprint a couple of times to see a trend here.
          </div>
        ) : (
          <div style={{ display: "flex", alignItems: "flex-end", gap: 10, height: 140, paddingTop: 10 }}>
            {last.map((h, i) => {
              const heightPct = (h.total / max) * 100;
              const isLast = i === last.length - 1;
              return (
                <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", height: "100%", justifyContent: "flex-end" }}>
                  <div style={{ fontSize: 10, fontFamily: "'Roboto', sans-serif", color: "#6B6253", marginBottom: 4 }}>{h.total}</div>
                  <div style={{
                    width: "100%", borderRadius: "5px 5px 0 0",
                    height: `${Math.max(heightPct, 4)}%`,
                    background: isLast ? PALETTE.clay : PALETTE.sageLight,
                  }} />
                  <div style={{ fontSize: 9.5, color: "#8A8073", marginTop: 6 }}>
                    {new Date(h.date).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      <Card style={{ marginTop: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <TrendingDown size={22} color={reduction != null && reduction > 0 ? PALETTE.sage : "#8A8073"} />
          <div>
            <div style={{ fontSize: 12, color: "#6B6253" }}>Emissions reduced vs last snapshot</div>
            <div style={{ fontFamily: "'Roboto', sans-serif", fontSize: 20, fontWeight: 700, color: PALETTE.forest }}>
              {reduction != null ? `${reduction > 0 ? reduction : 0}% reduction` : "—"}
            </div>
          </div>
        </div>
      </Card>

      <Card style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{
          width: 42, height: 42, borderRadius: "50%", background: PALETTE.amber,
          display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
        }}>
          <Award size={20} color="#fff" />
        </div>
        <div style={{ fontSize: 13.5, color: PALETTE.forest, fontWeight: 600 }}>
          {badges} Green {badges === 1 ? "Badge" : "Badges"} earned
        </div>
      </Card>

      <Card style={{ marginTop: 14 }}>
        <div style={{ fontFamily: "'Poppins', sans-serif", fontSize: 16, fontWeight: 600, color: PALETTE.forest, marginBottom: 4 }}>
          Saved results
        </div>
        <div style={{ fontSize: 12, color: "#6B6253", marginBottom: 12 }}>
          Every calculation is kept here — tap one to see its breakdown.
        </div>
        {reversedAll.length === 0 ? (
          <div style={{ textAlign: "center", color: "#8A8073", fontSize: 13, padding: "10px 0" }}>
            No saved results yet.
          </div>
        ) : (
          reversedAll.map((h, i) => {
            const isOpen = openIdx === i;
            const r = ratingFor(h.total);
            return (
              <div key={i} style={{
                borderTop: i === 0 ? "none" : `1px solid ${PALETTE.paperDim}`,
                padding: "10px 0",
              }}>
                <button onClick={() => setOpenIdx(isOpen ? null : i)} style={{
                  width: "100%", background: "none", border: "none", padding: 0,
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                }}>
                  <div style={{ textAlign: "left" }}>
                    <div style={{ fontSize: 12.5, fontWeight: 600, color: PALETTE.forest }}>
                      {new Date(h.date).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}
                    </div>
                    <div style={{ fontSize: 11, color: r.color, fontWeight: 700 }}>{r.label}</div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontFamily: "'Roboto', sans-serif", fontSize: 16, fontWeight: 700, color: PALETTE.forest }}>
                      {h.total} <span style={{ fontSize: 10, fontWeight: 500, color: "#8A8073" }}>kg</span>
                    </span>
                    <ChevronRight size={15} color="#8A8073" style={{ transform: isOpen ? "rotate(90deg)" : "none", transition: "transform 0.15s" }} />
                  </div>
                </button>
                {isOpen && (
                  <div style={{ marginTop: 10, paddingLeft: 2 }}>
                    {["Energy", "Water", "Transport", "Food", "Waste"].map((k) => (
                      <div key={k} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, padding: "3px 0" }}>
                        <span style={{ display: "flex", alignItems: "center", gap: 6, color: PALETTE.forest }}>
                          <span style={{ width: 8, height: 8, borderRadius: 2, background: CATEGORY_COLORS[k], display: "inline-block" }} />
                          {k}
                        </span>
                        <span style={{ fontFamily: "'Roboto', sans-serif", color: "#6B6253" }}>{h.breakdown[k]} kg</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
      </Card>

      <button onClick={onReset} style={{
        width: "100%", marginTop: 16, padding: "12px", borderRadius: 12, border: `1.5px solid ${PALETTE.paperDim}`,
        background: "transparent", color: "#8A8073", fontSize: 13, fontWeight: 600,
        display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
      }}>
        <RotateCcw size={14} /> Reset all data
      </button>
    </div>
  );
}

function AuthField({ icon: Icon, type = "text", placeholder, value, onChange, onEnter }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 8,
      border: `1.5px solid ${PALETTE.paperDim}`, borderRadius: 10, background: "#fff",
      padding: "11px 12px", marginBottom: 12,
    }}>
      <Icon size={16} color="#8A8073" />
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter" && onEnter) onEnter(); }}
        style={{
          flex: 1, border: "none", outline: "none", fontSize: 14,
          fontFamily: "'Poppins', sans-serif", color: PALETTE.ink, background: "transparent",
        }}
      />
    </div>
  );
}

function AuthScreen({ pendingOtp, pendingUser, error, onSendOtp, onVerifyOtp, onBack }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const awaitingOtp = !!pendingOtp;

  const submitSend = () => {
    onSendOtp({ name, email });
  };

  const submitVerify = () => {
    onVerifyOtp(otp);
  };

  return (
    <div style={{
      minHeight: "100vh", background: PALETTE.forestDeep,
      display: "flex", justifyContent: "center", alignItems: "center",
      padding: "24px 12px", fontFamily: "'Poppins', sans-serif",
    }}>
      <style>{FONTS}{`
        * { box-sizing: border-box; }
        button { font-family: 'Poppins', sans-serif; cursor: pointer; }
      `}</style>
      <div style={{
        width: 380, maxWidth: "100%", background: PALETTE.paper,
        borderRadius: 22, padding: "34px 26px", boxShadow: "0 30px 60px rgba(0,0,0,0.45)",
      }}>
        <div style={{ textAlign: "center", marginBottom: 22 }}>
          <div style={{
            width: 52, height: 52, borderRadius: 14, background: PALETTE.clay,
            display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px",
          }}>
            <Leaf size={26} color="#fff" />
          </div>
          <div style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 20, color: PALETTE.forest }}>
            Carbon Calculator
          </div>
          <div style={{ fontSize: 12.5, color: "#6B6253", marginTop: 4 }}>
            {awaitingOtp ? `Enter the code sent to ${pendingUser?.email}` : "No password needed — log in with a one-time code"}
          </div>
        </div>

        {!awaitingOtp ? (
          <div>
            <AuthField icon={User} placeholder="Full name (optional)" value={name} onChange={setName} />
            <AuthField icon={Mail} type="text" placeholder="Email or phone number" value={email}
              onChange={setEmail} onEnter={submitSend} />

            {error && (
              <div style={{ color: PALETTE.amber, fontSize: 12, marginBottom: 10, fontWeight: 600 }}>{error}</div>
            )}

            <button type="button" onClick={submitSend} style={{
              width: "100%", padding: "13px", borderRadius: 12, border: "none",
              background: PALETTE.clay, color: "#fff", fontSize: 14.5, fontWeight: 700, marginTop: 4,
              display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
            }}>
              <Lock size={15} /> Send one-time code
            </button>
          </div>
        ) : (
          <div>
            <div style={{
              background: "#fff", border: `1.5px dashed ${PALETTE.sage}`, borderRadius: 10,
              padding: "10px 12px", marginBottom: 14, textAlign: "center",
            }}>
              <div style={{ fontSize: 11, color: "#6B6253" }}>Demo mode — your code is</div>
              <div style={{ fontFamily: "'Roboto', sans-serif", fontSize: 22, fontWeight: 700, letterSpacing: 4, color: PALETTE.forest }}>
                {pendingOtp}
              </div>
            </div>

            <AuthField icon={Lock} type="text" placeholder="Enter 4-digit code" value={otp}
              onChange={setOtp} onEnter={submitVerify} />

            {error && (
              <div style={{ color: PALETTE.amber, fontSize: 12, marginBottom: 10, fontWeight: 600 }}>{error}</div>
            )}

            <button type="button" onClick={submitVerify} style={{
              width: "100%", padding: "13px", borderRadius: 12, border: "none",
              background: PALETTE.clay, color: "#fff", fontSize: 14.5, fontWeight: 700, marginTop: 4,
            }}>
              Verify & continue
            </button>
            <button type="button" onClick={onBack} style={{
              width: "100%", padding: "10px", borderRadius: 12, border: "none", background: "none",
              color: "#6B6253", fontSize: 12.5, fontWeight: 600, marginTop: 6,
            }}>
              Use a different email
            </button>
          </div>
        )}

        <div style={{ textAlign: "center", marginTop: 16, fontSize: 11.5, color: "#9A9181" }}>
          Fast access, no passwords to remember.
        </div>
      </div>
    </div>
  );
}
