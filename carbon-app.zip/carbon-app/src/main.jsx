import React from "react";
import ReactDOM from "react-dom/client";
import CarbonApp from "./CarbonApp.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <CarbonApp />
  </React.StrictMode>
);
