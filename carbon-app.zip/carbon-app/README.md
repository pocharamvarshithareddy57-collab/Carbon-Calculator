# Carbon Calculator — Real App గా Run చేయడం ఎలా

ఇది ఇప్పుడు ఒక పూర్తి **Vite + React** project. మీ computer లో run చేయాలంటే ఈ steps follow చేయండి.

## 1. అవసరమైనవి
- [Node.js](https://nodejs.org) install చేసుకోండి (version 18 లేదా అంతకంటే ఎక్కువ). Install అయ్యాక terminal లో `node -v` అని టైప్ చేస్తే version కనపడాలి.

## 2. Project folder open చేయండి
ఈ `carbon-app` folder ని డౌన్‌లోడ్ చేసి, terminal/command prompt లో ఆ folder లోపలికి వెళ్ళండి:

```bash
cd carbon-app
```

## 3. Dependencies install చేయండి
ఇది folder లో ఉన్న package.json చూసి అవసరమైన libraries (React, recharts, lucide-react) install చేస్తుంది:

```bash
npm install
```

## 4. Local గా run చేసి చూడండి
```bash
npm run dev
```
ఇది ఒక లింక్ ఇస్తుంది (ఉదా: `http://localhost:5173`) — అది బ్రౌజర్‌లో తెరిస్తే మీ యాప్ కనపడుతుంది.

## 5. Real website గా publish చేయడం (ఉచితం)

**ఈజీ మార్గం: Vercel**
1. https://vercel.com లో సైన్ అప్ చేయండి (GitHub account తో login చేయొచ్చు).
2. ఈ `carbon-app` folder ని GitHub repository గా push చేయండి.
3. Vercel లో "New Project" → ఆ repo select చేయండి → Deploy నొక్కండి.
4. కొన్ని సెకన్లలో మీకు ఒక live URL వస్తుంది (ఉదా: `carbon-calculator.vercel.app`) — అది ఎవరికైనా share చేయొచ్చు.

(అలాగే Netlify లేదా GitHub Pages కూడా వాడొచ్చు — process దాదాపు ఇలాగే ఉంటుంది.)

## ఇంకా గుర్తుంచుకోవాల్సినవి

- **Data ఎక్కడ save అవుతుంది?** ప్రస్తుతం ఈ యాప్ data ని ఆ device యొక్క బ్రౌజర్ `localStorage` లో save చేస్తుంది. అంటే ఒకే device/browser లో మాత్రమే data కనపడుతుంది; వేరే device లో login అయితే data కనపడదు. అన్ని devices లో data sync అవ్వాలంటే ఒక backend (Firebase/Supabase వంటివి) జోడించాలి.
- **OTP నిజంగా SMS/Email పంపదు** — ప్రస్తుతం demo కోసం code స్క్రీన్ మీదే చూపిస్తుంది. నిజమైన SMS/Email పంపాలంటే Twilio లేదా email service తో backend integration చేయాలి.
- **Mobile app (Play Store/App Store) కావాలంటే** — ఈ web app నే [Capacitor](https://capacitorjs.com) వాడి Android/iOS app గా wrap చేయొచ్చు.
